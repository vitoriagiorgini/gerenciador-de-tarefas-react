import React, { useState } from 'react';

function Formulario({ onAddTask }) {

  const [tarefa, setTarefa] = useState(
    {
    titulo: '',
    descricao: '',
    dataVencimento: '',
    status: 'Pendente', 
  }
);

  
  function handleFields(e) {
    const { name, value } = e.target; 
    setTarefa({
      ...tarefa, 
      [name]: value, 
    });
  }

  const handleSubmit = (e) => {
    e.preventDefault(); 

    if (!tarefa.titulo.trim() || !tarefa.descricao.trim()) {
      alert('Título e descrição da tarefa não podem ser vazios!');
      return;
    }

    onAddTask({ ...tarefa, id: Date.now() }); 

    
    setTarefa({
      titulo: '',
      descricao: '',
      dataVencimento: '',
      status: 'Pendente',
    });
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '20px', padding: '20px', border: '1px solid #ccc', borderRadius: '8px' }}>
      <h2>Criar Nova Tarefa</h2>
      <div>
        <label htmlFor="titulo">Título da Tarefa:</label>
        <input
          type="text"
          id="titulo"
          name="titulo" 
          value={tarefa.titulo}
          onChange={handleFields}
          required
        />
      </div>
      <div>
        <label htmlFor="descricao">Descrição da Tarefa:</label>
        <textarea
          id="descricao"
          name="descricao" 
          value={tarefa.descricao}
          onChange={handleFields} 
          required
        ></textarea>
      </div>
      <div>
        <label htmlFor="dataVencimento">Data de Vencimento:</label>
        <input
          type="date"
          id="dataVencimento"
          name="dataVencimento" 
          value={tarefa.dataVencimento}
          onChange={handleFields} 
        />
      </div>
      <div>
        <label htmlFor="status">Status:</label>
        <select
          id="status"
          name="status" 
          value={tarefa.status}
          onChange={handleFields} 
        >
          <option value="Pendente">Pendente</option>
          <option value="Concluída">Concluída</option>
        </select>
      </div>
      <button type="submit">Adicionar Tarefa</button> {/* onClick já está no onSubmit do form */}
    </form>
  );
}

export default Formulario; 