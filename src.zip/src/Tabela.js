import React from 'react';

function Tabela({ tarefas }) {
  return (
    <div style={{ marginTop: '30px' }}>
      <h2>Lista de Tarefas</h2>
      {tarefas.length === 0 ? (
        <p>Nenhuma tarefa adicionada ainda.</p>
      ) : (
        <table className="tabela-tarefas"> {/* Adicione uma classe para estilização */}
          <thead>
            <tr>
              <th>Título</th>
              <th>Descrição</th>
              <th>Data de Vencimento</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {tarefas.map((tarefa) => (
              // 6. Coloque o “background” da linha da tabela na cor verde quando o status
              //    da tarefa estiver “Concluída” e vermelho quando a tarefa estiver “Pendente”.
              <tr key={tarefa.id} className={tarefa.status === 'Concluída' ? 'concluida' : 'pendente'}>
                <td>{tarefa.titulo}</td>
                <td>{tarefa.descricao}</td>
                <td>{tarefa.dataVencimento || 'N/A'}</td> {/* Exibe N/A se a data não for preenchida */}
                <td>{tarefa.status}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default Tabela; // 8. Exporte o componente