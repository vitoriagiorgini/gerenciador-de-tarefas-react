import React, { useState } from 'react'; // Importe useState, pois a lógica de estado virá para cá
import ReactDOM from 'react-dom/client';
import './index.css'; // Estilos globais
import Formulario from './Formulario'; // Importe o componente Formulario
import Tabela from './Tabela';       // Importe o componente Tabela
import './App.css'; // Importe App.css aqui, pois ele contém estilos para a div principal "App"
import reportWebVitals from './reportWebVitals';

// A lógica que antes estava no componente App.jsx
function MainApplication() {
  const [tarefas, setTarefas] = useState([]);

  const handleAddTask = (novaTarefa) => {
    setTarefas([...tarefas, novaTarefa]);
  };

  return (
    <div className="App"> {/* A classe "App" é mantida para que o CSS funcione */}
      <h1>Gerenciador de Tarefas</h1>
      <Formulario onAddTask={handleAddTask} />
      <Tabela tarefas={tarefas} />
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <MainApplication /> {/* Renderiza o novo componente principal */}
  </React.StrictMode>
);

reportWebVitals();